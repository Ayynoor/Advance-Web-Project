// ======================================
// NAVBAR SCROLL EFFECT
// ======================================

const navbar = document.querySelector(".custom-navbar");

window.addEventListener("scroll", function () {

    if (window.scrollY > 50) {
        navbar.classList.add("scrolled");
    } else {
        navbar.classList.remove("scrolled");
    }

});


// ======================================
// SCROLL REVEAL ANIMATION
// ======================================

const revealElements = document.querySelectorAll(
    ".reveal, .reveal-left, .reveal-right"
);

const observer = new IntersectionObserver(

    function (entries) {

        entries.forEach(function (entry) {

            if (entry.isIntersecting) {

                entry.target.classList.add("active");

                observer.unobserve(entry.target);

            }

        });

    },

    {
        threshold: 0.15
    }

);

revealElements.forEach(function (element) {

    observer.observe(element);

});


// ======================================
// COUNTER ANIMATION
// ======================================

const counters = document.querySelectorAll(".counter");

let countersStarted = false;

function startCounters() {

    if (countersStarted) {
        return;
    }

    const heroStats = document.querySelector(".hero-stats");

    if (!heroStats) {
        return;
    }

    const position =
        heroStats.getBoundingClientRect().top;

    if (position < window.innerHeight) {

        countersStarted = true;

        counters.forEach(function (counter) {

            const target =
                Number(counter.getAttribute("data-target"));

            let current = 0;

            const increment =
                Math.max(1, Math.floor(target / 100));

            function updateCounter() {

                current += increment;

                if (current < target) {

                    counter.innerText =
                        current.toLocaleString() + "+";

                    requestAnimationFrame(updateCounter);

                } else {

                    counter.innerText =
                        target.toLocaleString() + "+";

                }

            }

            updateCounter();

        });

    }

}

window.addEventListener("scroll", startCounters);

window.addEventListener("load", startCounters);


// ======================================
// SAVE JOB BUTTON
// ======================================

const saveButtons =
    document.querySelectorAll(".save-job");

saveButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        button.classList.toggle("saved");

        const icon = button.querySelector("i");

        if (button.classList.contains("saved")) {

            icon.classList.remove("bi-heart");
            icon.classList.add("bi-heart-fill");

        } else {

            icon.classList.remove("bi-heart-fill");
            icon.classList.add("bi-heart");

        }

    });

});


// ======================================
// CATEGORY CARD 3D EFFECT
// ======================================

const cards =
    document.querySelectorAll(".category-card");

cards.forEach(function (card) {

    card.addEventListener("mousemove", function (event) {

        const rect =
            card.getBoundingClientRect();

        const x =
            event.clientX - rect.left;

        const y =
            event.clientY - rect.top;

        const centerX =
            rect.width / 2;

        const centerY =
            rect.height / 2;

        const rotateX =
            (y - centerY) / 20;

        const rotateY =
            (centerX - x) / 20;

        card.style.transform =
            `perspective(1000px)
             rotateX(${rotateX}deg)
             rotateY(${rotateY}deg)
             translateY(-10px)`;

    });


    card.addEventListener("mouseleave", function () {

        card.style.transform =
            "perspective(1000px) rotateX(0) rotateY(0)";

    });

});


// ===========================================================
// Live search + category filter (jobs.html, freelancers.html)
// ===========================================================

const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const items = document.querySelectorAll(".filter-item");
const noResults = document.querySelector(".no-results");
 
function applyFilter() {
    const text = searchInput ? searchInput.value.toLowerCase().trim() : "";
    const cat = categoryFilter ? categoryFilter.value : "all";
    let visible = 0;
    items.forEach(function (item) {
        const matchText = item.textContent.toLowerCase().includes(text);
        const matchCat = cat === "all" || item.dataset.category === cat;
        const show = matchText && matchCat;
        item.style.display = show ? "" : "none";
        if (show) visible++;
    });
    if (noResults) noResults.style.display = visible ? "none" : "block";
}
if (searchInput) searchInput.addEventListener("input", applyFilter);
if (categoryFilter) categoryFilter.addEventListener("change", applyFilter);



// ====================
// Show / hide password
// ====================

document.querySelectorAll(".toggle-password").forEach(function (btn) {
    btn.addEventListener("click", function () {
        const input = btn.parentElement.querySelector("input");
        const icon = btn.querySelector("i");
        const show = input.type === "password";
        input.type = show ? "text" : "password";
        icon.className = show ? "bi bi-eye-slash" : "bi bi-eye";
    });
});



// ==========================================
// Form validation (contact, login, register)
// ==========================================

document.querySelectorAll("form.validate-form").forEach(function (form) {
    form.addEventListener("submit", function (e) {
        e.preventDefault();
        const msg = form.querySelector(".form-msg");
        const pass = form.querySelector("#password");
        const confirm = form.querySelector("#confirmPassword");
        let error = "";
        if (!form.checkValidity()) error = "Please fill in all required fields correctly.";
        else if (pass && pass.value.length < 6) error = "Password must be at least 6 characters.";
        else if (pass && confirm && pass.value !== confirm.value) error = "Passwords do not match.";
        msg.style.display = "block";
        if (error) {
            msg.className = "form-msg alert alert-danger";
            msg.textContent = error;
        } else {
            msg.className = "form-msg alert alert-success";
            msg.textContent = form.dataset.success || "Done!";
            form.reset();
        }
    });
});